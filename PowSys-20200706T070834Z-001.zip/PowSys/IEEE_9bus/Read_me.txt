Jaikumar Pettikkattil
     
IEEE 9 BUs Simulink


 #### slblocks.m

 #### Make sure the library file is in the matlab path
 #### To to do Load flow open the POwer gui block and hit Load flow -> compute -> Update
