clear all
clc
ch = input('Enter the bus system no.: (6 or 9 or 14 or 26 or 30 or 57): ');
while ch ~= 6 && ch ~= 14 && ch ~= 26 && ch ~= 30 && ch ~= 57 && ch ~= 9
    fprintf('Invalid Input try again\n');
    ch = input('Enter the bus system no.: (6 or 9 or 14 or 26 or 30 or 57): ');
end
switch ch
    case 6
        data6
    case 14
        data14
    case 26
        data26
    case 30
        data30
    case 57
        data57
    case 9
        data9
end
met = input('Enter the method for load flow (1 - GS, 2 - NR, 3 - Fast Decouple): ');
while met ~= 1 && met ~= 2 && met ~= 3
    fprintf('Invalid Input try again\n');
    met = input('Enter the method for load flow (1 - GS, 2 - NR, 3 - Fast Decouple): ');
end
switch met
    case 1
        maingauss
    case 2
        mainnewton
    case 3
        maindecouple
end